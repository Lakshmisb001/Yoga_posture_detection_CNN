#Git clone

git clone https://github.com/SumanthN16/yogapose.git
cd yogapose

# installation comments

# Create Env
python -m venv .venv

# Activate Env
.venv\Scripts\activate

#Install Requirements
pip install -r requirements.txt

# run
python server.py
